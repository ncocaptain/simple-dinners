// core/planner.ts
import type { Meal, PantryItem, Effort } from "./types";

// --------------------
// Basic helpers
// --------------------
export function normalize(s: string) {
  return (s || "")
    .toLowerCase()
    .replace(/[^\w\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// --------------------
// Pantry scoring
// --------------------
export function getPantryTokens(pantry: PantryItem[]) {
  if (!Array.isArray(pantry)) return [];
  return pantry
    .map((p) => normalize(p.name))
    .flatMap((s) => s.split(/[\n,;/|]/g))
    .map((s) => s.trim())
    .filter(Boolean);
}

export function scoreMealAgainstPantry(meal: Meal, tokens: string[]) {
  if (!tokens.length) return 0;

  const nameHay = normalize(meal.name || "");
  const ingHay = normalize(meal.ingredients || "");

  let score = 0;
  for (const t of tokens) {
    if (t.length < 3) continue;
    if (ingHay.includes(t)) score += 3; // strong
    if (nameHay.includes(t)) score += 1; // small boost
  }
  return score;
}

// --------------------
// Substitutions / libraries (placeholders)
// --------------------
export const SUBS: Array<{ pattern: RegExp; replacement: string }> = [
  // { pattern: /ground beef/gi, replacement: "lentils" },
];

export const candidateLibrary: Meal[] = [
  // your seed meals here
];

export const allergenKeywords: string[] = [
  // "peanut", "tree nut", "shellfish", etc
];

export function violatesAllergens(ingredients: string) {
  // implement using allergenKeywords + prefs if needed
  return false;
}

export function isVegetarianByHeuristic(ingredients: string) {
  // implement your heuristic here
  return false;
}

// --------------------
// Pure plan generator (NO React, NO navigate)
// --------------------
export function generatePlan(args: {
  meals: Record<string, Meal>;
  cookbook: Array<{ name: string; ingredients: string; instructions?: string; photoUrl?: string }>;
  candidateLibrary: Meal[];
  pantry: PantryItem[];
  daySettings: Record<string, Effort>;
  prefs: { vegetarian: boolean; allowSubstitutions: boolean };
  days: readonly string[];
}) {
  const { meals, cookbook, candidateLibrary, pantry, daySettings, prefs, days } = args;

  const pantryTokens = getPantryTokens(pantry);

  // build pool...
  const pool: Meal[] = [...candidateLibrary]; // expand with cookbook conversion as you do in App

  // rank pantry-first
  const ranked = pool
    .map((m) => ({ m, score: scoreMealAgainstPantry(m, pantryTokens) }))
    .sort((a, b) => b.score - a.score)
    .map((x) => x.m);

  const next: Record<string, Meal> = { ...meals };
  const used = new Set<string>();

  for (const d of days) {
    const existing = next[d]?.name?.trim();
    if (existing) used.add(normalize(existing));
  }

  for (const day of days) {
    const existing = next[day];
    if (existing?.name?.trim()) continue;

    const needed = daySettings[day] || "normal";

    if (needed === "takeout") {
      next[day] = {
        name: "Takeout Night",
        ingredients: "order out (no groceries)",
        effort: "takeout",
      };
      continue;
    }

    const pick = ranked.find((m) => !used.has(normalize(m.name))) || ranked[0];
    if (pick) {
      next[day] = pick;
      used.add(normalize(pick.name));
    }
  }

  return next;
}
