// --- Helpers ---
export function normalize(s: string) {
  return (s || "").trim().toLowerCase();
}

// Allergens
  const allergenKeywords = useMemo(() => {
    return ALLERGENS.filter((a) => (effectivePrefs.allergens || []).includes(a.key)).flatMap((a) =>
      a.keywords.map(normalize)
    );
  }, [effectivePrefs.allergens]);

  const violatesAllergens = (ingredients: string) => {
    const ing = normalize(ingredients);
    return allergenKeywords.some((bad) => ing.includes(bad));
  };

  const isVegetarianByHeuristic = (ingredients: string) => {
    const ing = normalize(ingredients);
    return !MEAT_WORDS.some((w) => ing.includes(normalize(w)));
  };

  // Candidate library filtered for prefs
  const candidateLibrary = useMemo(() => {
    let list = MEAL_LIBRARY.filter((m) => !violatesAllergens(m.ingredients));

    if (effectivePrefs.vegetarian) {
      if (effectivePrefs.allowSubstitutions) {
        list = list.map(applyVegSub);
      } else {
        list = list.filter((m) => isVegetarianByHeuristic(m.ingredients));
      }
    }

    return list.filter((m) => !violatesAllergens(m.ingredients));
  }, [effectivePrefs.vegetarian, effectivePrefs.allowSubstitutions, allergenKeywords]);