export type Effort = "quick" | "normal" | "big" | "takeout";

export type Meal = {
  name: string;
  ingredients: string;
  instructions?: string;
  photoUrl?: string;
  description?: string;
  prepMinutes?: number;
  servings?: number;
  rating?: number;
  effort?: Effort;
};

export type PantryItem = {
  id: string;
  name: string;
  qty?: string;
  unit?: string;
  category?: string;
  expiresAt?: number;
  createdAt: number;
  updatedAt?: number;
};